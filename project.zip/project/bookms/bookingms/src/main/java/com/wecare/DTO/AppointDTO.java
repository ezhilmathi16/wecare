package com.wecare.DTO;

import java.time.LocalDate;



public class AppointDTO {
	LocalDate appointmentDate;
	String slot;
	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(LocalDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	@Override
	public String toString() {
		return "AppointDTO [appointmentDate=" + appointmentDate + ", slot=" + slot + "]";
	}
	
	
	
	
}
